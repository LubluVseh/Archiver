import ui.MainWindow

if __name__ == '__main__':
    ui.MainWindow.init()

